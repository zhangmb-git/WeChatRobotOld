#include "stdafx.h"
#include "MyMath.h"

// CMyMath

STDMETHODIMP CMyMath::Test(void)
{
	AFX_MANAGE_STATE(AfxGetStaticModuleState());

	return S_OK;
}
